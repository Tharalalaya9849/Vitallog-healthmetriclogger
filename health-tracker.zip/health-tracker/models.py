from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

# Initialize the database object
db = SQLAlchemy()

class HealthMetrics(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    blood_pressure = db.Column(db.String(100), nullable=False)
    weight = db.Column(db.Float, nullable=False)
    blood_sugar = db.Column(db.Float, nullable=False)
    date_recorded = db.Column(db.Date, nullable=False)

    def __repr__(self):
        return f'<HealthMetric {self.id}>'

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(150), unique=True, nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return f'<User {self.username}>'

    # Method to check if password is correct
    def check_password(self, password):
        return check_password_hash(self.password, password)

    # Method to hash the password
    def set_password(self, password):
        self.password = generate_password_hash(password)


