from flask import Flask, render_template, request, redirect, url_for, flash, session
from datetime import datetime
from models import db, User, HealthMetrics
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)

# Configure the database URI (SQLite example)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///health_tracker.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'your_secret_key'  # For session management

db.init_app(app)

@app.route('/')
def home():
    if 'user_id' in session:
        return render_template('home.html')  # Home page if logged in
    else:
        return redirect(url_for('login'))  # Redirect to login if not logged in

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        # Find the user by email
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id  # Store user id in the session
            flash('Login successful', 'success')
            return redirect(url_for('home'))
        else:
            flash('Invalid login credentials', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return redirect(url_for('register'))

        # Check if email already exists
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'danger')
            return redirect(url_for('register'))
        
        # Create new user
        new_user = User(username=username, email=email)
        new_user.set_password(password)  # Set hashed password
        db.session.add(new_user)
        db.session.commit()

        flash('Account created successfully, please log in', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)  # Remove user from session
    flash('You have been logged out', 'success')
    return redirect(url_for('login'))

@app.route('/add_health_metrics', methods=['GET', 'POST'])
def add_health_metrics():
    if 'user_id' not in session:
        flash('You need to log in first', 'warning')
        return redirect(url_for('login'))

    if request.method == 'POST':
        # Getting form data
        blood_pressure = request.form['blood_pressure']
        weight = float(request.form['weight'])
        blood_sugar = float(request.form['blood_sugar'])
        date_recorded = datetime.strptime(request.form['date_recorded'], '%Y-%m-%d')

        # Create a new HealthMetrics object and add to the database
        new_health_metric = HealthMetrics(
            blood_pressure=blood_pressure,
            weight=weight,
            blood_sugar=blood_sugar,
            date_recorded=date_recorded
        )

        # Add to the database and commit
        db.session.add(new_health_metric)
        db.session.commit()

        # Redirect to the home page or success page
        flash('Health metric added successfully!', 'success')
        return redirect(url_for('home'))

    return render_template('add_health_metrics.html')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create the tables if they don't exist yet
    app.run(debug=True)
